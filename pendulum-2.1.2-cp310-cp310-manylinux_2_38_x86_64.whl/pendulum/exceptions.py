from .parsing.exceptions import ParserError  # noqa


class PendulumException(Exception):

    pass
